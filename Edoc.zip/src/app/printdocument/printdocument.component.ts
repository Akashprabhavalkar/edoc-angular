import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { APIService } from '../api.service';
import { CookieService } from '../cookie.service';

@Component({
  selector: 'app-printdocument',
  templateUrl: './printdocument.component.html',
  styleUrls: ['./printdocument.component.css']
})
export class PrintdocumentComponent implements OnInit {

  employee: any;
  document: any;
  words:any;
  documentid:string | null = "";
  employeeid:string | null = "";
  content:string = "";

  constructor(private api: APIService, private cookie: CookieService, private router: Router, private activatedRoute: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.employeeid = this.activatedRoute.snapshot.paramMap.get("eid");
    this.documentid = this.activatedRoute.snapshot.paramMap.get("did");
    
    let apiurl = "words/list";
    let dataWords = this.api.post(apiurl, {});
   

    apiurl = "documents/get";
    let dataDocument = this.api.post(apiurl, { data: { id: this.documentid } });
  
    apiurl = "employees/get";
    let dataEmployee = this.api.post(apiurl, { data: { id: this.employeeid } });
  
    forkJoin([dataWords, dataEmployee, dataDocument]).subscribe((responses:any)=>{
      console.log(responses);
        // dataWords.subscribe((mydata: any) => {
          this.words = responses[0].data;
          this.employee = responses[1].data;
          this.document = responses[2].data;
        // });

        // dataDocument.subscribe((mydata: any) => {
        //   this.document = mydata.data;    
        //   console.log(this.document);
        // });
        // dataEmployee.subscribe((mydata: any) => {
        //       this.employee = mydata.data;      
        //       console.log(this.employee);
        // });
        this.change();
    });
  }

  change() {
  
      if(this.employee.gender == "Male")
      {
        this.content = this.document.malecontents;
      }
      else{
        this.content = this.document.femalecontents;
      }
    console.log("employees");
    console.log(this.employee);
    console.log("documents");
    console.log(this.document);
    console.log("words");
    console.log(this.words);
    this.words.forEach((word:any) => {
      let replacewith = "";
      if(word.replacewith == "name"){
        replacewith = this.employee.name;
      }
      else if(word.replacewith == "joiningdate"){
        replacewith = this.employee.joiningdate;
      }
      else if(word.replacewith == "relievingdate"){
        replacewith = this.employee.relievingdate;
      }
       this.content = this.content.replace(word.keyword, replacewith);
      
    });
  }
}
