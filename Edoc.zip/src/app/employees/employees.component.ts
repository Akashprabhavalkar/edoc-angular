import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { APIService } from '../api.service';
import { CookieService } from '../cookie.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  employees:any;
  documents:any;
  baseurl:string = this.api.baseUrl;

  constructor(private api: APIService, private cookie: CookieService, private router: Router) {
  }

  ngOnInit(): void {    
    this.documentlist();
  }

  documentlist()
  {
    let apiurl = "documents/list";
    let data = this.api.post(apiurl, {});
    data.subscribe((mydata: any) => {
      this.documents= mydata.data;
      console.log(this.documents);
      this.list();
    });
  }

  list()
  {
    let apiurl = "employees/list";
    let data = this.api.post(apiurl, {});
    data.subscribe((mydata: any) => {
      this.employees= mydata.data;
      console.log(this.employees);
    });
  }

  delete(id:string)
  {
    if(confirm("Sure to delete?"))
    {
      let apiurl = "employees/delete";
    let data = this.api.post(apiurl, {data:{id:id}});
    data.subscribe((mydata: any) => {
      this.list();
    });
    }
  }


}
